aws s3 cp . s3://todo1.terrillo.com/ --recursive --exclude ".git/*"

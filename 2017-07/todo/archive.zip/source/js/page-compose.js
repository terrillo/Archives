// Compose
myApp.onPageInit('compose', function (page) {
  
});

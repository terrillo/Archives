var strings = {
  
}

# Milo (UI)
A %100 different new UI framework. Milo (UI) doesn't feel or look like Material Design, Metro, Bootstrap or whatever. Milo UI is about rethinking everything. A design system with the CSS framework to back it up. Anything goes.

## High level concepts
**Four Colors**
- Two saturated colors
- Two hue colors
- The default colors are white, dark gray, rose gold, and cyan

**Fonts**
- Mono font styles

**Never in Milo UI**
- Shadows

kill -9 $(lsof -t -i:88)
python app.py

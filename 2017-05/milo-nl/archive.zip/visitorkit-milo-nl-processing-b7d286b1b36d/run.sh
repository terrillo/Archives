kill -9 $(lsof -t -i:8089)
python app.py

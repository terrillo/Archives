from interface.classify import *

print classify('close project')

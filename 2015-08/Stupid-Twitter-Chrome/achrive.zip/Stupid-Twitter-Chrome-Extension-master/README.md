# Stupid Twitter Chrome Extension

## Make Twitter.com a better place.
- Auto show new tweets
- Display images inline like the mobile app.

### 1.1v Changelog
- New New from "Stupid Twitter" to "Twitter Pro User"
- Auto show tweets (Bug fixes)
